package com.hrms.utility;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass {
	public static WebDriver driver;
	//public static String index;
	public static String url;
	public static void openApplication(String url)
	{
		System.setProperty("webdriver.chrome.driver", "D:\\JarFiles\\Drivers\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get(url);
	}
	
	public static void closeApplication()
	{
		driver.quit();
	}
	public static void switchtoFrame(int index)
	{
		driver.switchTo().frame(index);
	}
	public static void outOfFrame()
	{
		driver.switchTo().defaultContent();
	}
	

}
