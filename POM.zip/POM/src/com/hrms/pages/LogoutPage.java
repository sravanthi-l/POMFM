package com.hrms.pages;
import com.hrms.utility.BaseClass;
import org.openqa.selenium.By;
import org.testng.Reporter;

public class LogoutPage extends BaseClass {
	public static void logout()
	{
		driver.quit();
		Reporter.log("logout done successfully");
	}
	
	
}
