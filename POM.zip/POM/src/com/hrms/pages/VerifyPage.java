package com.hrms.pages;
import org.testng.Reporter;

import com.hrms.utility.*;
public class VerifyPage extends BaseClass {
	static String expectedtitle="OrangeHRM";
	
	public static void verifyTitle()
	{
	if(driver.getTitle().equals(expectedtitle))	
			{
		Reporter.log("title matched");
			}
	else
	{
		Reporter.log("title not macthed");
	}
	}
	
	

}
