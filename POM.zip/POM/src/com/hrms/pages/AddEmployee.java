package com.hrms.pages;
import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import com.hrms.utility.*;



public class AddEmployee extends BaseClass {
 
	
			static By obj_Add=By.xpath("//input[@value='Add']");
		    static By obj_firstnm=By.xpath("//input[@name='txtEmpFirstName']");
		    static By obj_lstname=By.xpath("//input[@name='txtEmpLastName']");
			static By txt_empid=By.id("//input[@id='txtEmployeeId']");
			static By obj_save=By.xpath("//input[@value='Save']");
			//static By obj_back=By.xpath("//input[@value='Back']");
	public static void addEmployee(String frstnm,String lstnm) throws Exception
	{
	
	driver.findElement(obj_Add).click();
	driver.findElement(obj_firstnm).sendKeys(frstnm);
	driver.findElement(obj_lstname).sendKeys(lstnm);
	driver.findElement(obj_save).click();
	Thread.sleep(3000);
	Reporter.log(frstnm+"employee added");
	System.out.println("employee added");
		
	}
	}
