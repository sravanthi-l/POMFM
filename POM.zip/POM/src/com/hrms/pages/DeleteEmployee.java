package com.hrms.pages;
import com.hrms.utility.*;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
public class DeleteEmployee extends AddEmployee {
	
static By obj_delete=By.xpath("//input[@value='Delete']");
static By obj_back=By.xpath("//input[@value='Back']");

//static String expectedempid=AddEmployee.employeeid;
static String actualempid;
//static WebElement wtbl=driver.findElement(By.xpath("//table[@class='data-table']"));
/*static int rowcnt=driver.findElements(By.xpath("//table[@class='data-table']/tbody/tr")).size();   
static int colcnt=driver.findElements(By.xpath("//table[@class='data-table']/tbody/tr[1]/td")).size();
static int rowcolcnt=driver.findElements(By.xpath("//table[@class='data-table']/tbody/tr/td")).size();
//public static String employeeid=driver.findElement(By.name("txtEmployeeId")).getText(); */
	


public static void deleteEmployee () throws Exception
{  
	
	driver.switchTo().frame("rightMenu");

	String employeeid=driver.findElement(By.name("txtEmployeeId")).getText();
    System.out.println(employeeid);
    Reporter.log(employeeid);
    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.findElement(obj_back).click();
	
	int rowcnt=driver.findElements(By.xpath("//table[@class='data-table']/tbody/tr")).size();   
	int colcnt=driver.findElements(By.xpath("//table[@class='data-table']/tbody/tr[1]/td")).size();
	int rowcolcnt=driver.findElements(By.xpath("//table[@class='data-table']/tbody/tr/td")).size();

     Reporter.log("row count is"+ rowcnt );
     Reporter.log("column count" + colcnt);
     /*static int rowcnt=driver.findElements(By.xpath("//table[@class='data-table']/tbody/tr")).size();   
     static int colcnt=driver.findElements(By.xpath("//table[@class='data-table']/tbody/tr[1]/td")).size();
     static int rowcolcnt=driver.findElements(By.xpath("//table[@class='data-table']/tbody/tr/td")).size(); */

     Thread.sleep(3000);
	
	
	
	 for(int i=1;i<=rowcnt;i++) {
	 
	 actualempid= driver.findElement(By.xpath("//table[@class='data-table']/tbody/tr["+i+"]/td[2]")).getText();
	 //Reporter.log(actualempid);
			
		if(actualempid.equals(employeeid))
		 { 
			
			break;
		 }
			
		System.out.println(i);
		 driver.findElement(By.xpath("//table[@class='data-table']/tbody/tr["+i+"]/td[1]")).click();
		 driver.findElement(obj_delete).click();
		 Reporter.log("Deleted employee"+ actualempid);
		
 
	 
 }
	 	
 
}
}


                                          