package com.hrms.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.hrms.utility.*;
import com.hrms.utility.BaseClass;
import org.testng.Reporter;

public class Loginpage extends BaseClass {
	

static By txt_loginname =By.name("txtUserName");
static By txt_password = By.xpath("//input[@name='txtPassword']");
static By btn_login = By.name("Submit");
//public static String username,password;

	public static void login(String username,String password) throws Exception{
		driver.findElement(txt_loginname).sendKeys(username);
		driver.findElement(txt_password).sendKeys(password);
		WebElement ele=driver.findElement(By.name("Submit"));
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", ele);
		//driver.findElement(btn_login).click();
		Reporter.log("login completed");
		driver.manage().timeouts();
		
	}

}
