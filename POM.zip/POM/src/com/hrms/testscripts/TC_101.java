package com.hrms.testscripts;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.hrms.pages.Loginpage;
import com.hrms.pages.AddEmployee;
import com.hrms.pages.AddEmployee;
import com.hrms.pages.LogoutPage;
import com.hrms.pages.VerifyPage;
import com.hrms.pages.DeleteEmployee;
import com.hrms.utility.BaseClass;

public class TC_101 extends BaseClass{
	
@Test
public static void setUp() throws Exception
{
	BaseClass.openApplication("http://localhost/orangehrm/orangehrm-2.6/orangehrm-2.6/login.php");
	Loginpage.login("admin","admin");
	System.out.println("login done");
	Thread.sleep(3000);
	VerifyPage.verifyTitle();
	Thread.sleep(3000);
	BaseClass.switchtoFrame(0);
	AddEmployee.addEmployee("indiramma","sonnathi");
	
	BaseClass.outOfFrame();
	//Thread.sleep(3000);
	
	//driver.switchTo().frame(0);
	
	DeleteEmployee.deleteEmployee();
	Thread.sleep(3000);
	BaseClass.outOfFrame();
	LogoutPage.logout();
	BaseClass.closeApplication(); 
	
}
	
}
